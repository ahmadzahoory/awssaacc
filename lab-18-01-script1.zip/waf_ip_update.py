"""
Update an AWS IP set with the the top 10 IP addresses from Apache logs
"""
import sys
import re
import boto3
from collections import Counter
from tabulate import tabulate
import ipaddress


def get_top_n_ipv4_addresses(num):
    """
    Parses apache logs to find the top n X-Forwarded-For ipv4 addresses
    """
    all_ipv4_addresses = []

    with open('/var/log/httpd/access_log') as content:
        for line in content:
            # the first "cell" surrounded with brackets is the X-Forwarded-For
            regex = re.search(r'\((.*?)\)', line)
            if regex:
                try:
                    forwarded_for = ipaddress.ip_address(regex.group(0).strip("()"))
                    if forwarded_for.version == 4:
                        all_ipv4_addresses.append(forwarded_for.__str__())
                except:
                    continue

    return Counter(all_ipv4_addresses).most_common(num)


def get_top_n_ipv6_addresses(num):
    """
    Parses apache logs to find the top n X-Forwarded-For ipv6 addresses
    """
    all_ipv6_addresses = []

    with open('/var/log/httpd/access_log') as content:
        for line in content:
            # the first "cell" surrounded with brackets is the X-Forwarded-For
            regex = re.search(r'\((.*?)\)', line)
            if regex:
                try:
                    forwarded_for = ipaddress.ip_address(regex.group(0).strip("()"))
                    if forwarded_for.version == 6:
                        all_ipv6_addresses.append(forwarded_for.__str__())
                except:
                    continue

    return Counter(all_ipv6_addresses).most_common(num)


def main():
    """
    Grab top 10 X-Forwarded-For ip addresses and send to a WAF ip list
    """
    top_ipv4_addresses = get_top_n_ipv4_addresses(10)
    top_ipv6_addresses = get_top_n_ipv6_addresses(10)

    print
    print("Top 10 IPv4 Addresses")
    print("===================")
    print
    print(tabulate(top_ipv4_addresses, headers=["IP", "Count"]))
    print

    print
    print("Top 10 IPv6 Addresses")
    print("===================")
    print
    print(tabulate(top_ipv6_addresses, headers=["IP", "Count"]))
    print

    waf = boto3.client('wafv2', region_name='us-east-1')
    
    waf_ip_sets = waf.list_ip_sets(Scope='CLOUDFRONT',
        Limit=100
    )['IPSets']

    if len(waf_ip_sets) < 1:
        sys.exit('WAF IP sets appear to be misconfigured.  Expecting 1 IP set.')

    waf_ip_set_id = waf_ip_sets[0]['Id']
    print("Updating IP set: ", waf_ip_sets[0]['Name'])

    if top_ipv4_addresses.__len__() != 0:
        for ipv4 in top_ipv4_addresses:

            waf.update_ip_set(Name=waf_ip_sets[0]['Name'],Id=waf_ip_set_id,Scope='CLOUDFRONT',Addresses=[ipv4[0]+'/32'],LockToken=waf_ip_sets[0]['LockToken'])

    if top_ipv6_addresses.__len__() != 0:

        for ipv6 in top_ipv6_addresses:

            waf.update_ip_set(Name=waf_ip_sets[0]['Name'],Id=waf_ip_set_id,Scope='CLOUDFRONT',Addresses=[ipv6[0]+'/128'],LockToken=waf_ip_sets[0]['LockToken'])

    print("Done!")


if __name__ == "__main__":
    main()