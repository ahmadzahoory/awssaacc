<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title><?php
          $title = (array_key_exists('HTTP_X_AMZ_CF_ID', $_SERVER) ? "CloudFrontURL" : "WebsiteURL");
          echo $title;
        ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="assets/css/bootstrap.min.css" rel="stylesheet">
        <style>body {margin-top: 40px; background-color: #333;}</style>
        <link href="assets/css/bootstrap-responsive.min.css" rel="stylesheet">
        <!--[if lt IE 9]><script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    </head>

    <body>
        <div class="container">
            <div class="hero-unit">
              <h1>HTTP Request Headers</h1>
              <?php
                 foreach($_SERVER as $key => $val)
                 {
                    if (substr($key, 0, strlen("HTTP")) === "HTTP") {
                       echo "<p><b>" . htmlspecialchars($key) . "</b> ";
                       echo htmlspecialchars($val) . "</p>\n";
                    }
                 }
              ?>
            </div>
        </div>

        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
    </body>

</html>
